Qwen3.7-Plus M5 CerebraFusionMemory / RRSI-S10

100 paired validation questions: 70 Rad-ReStruct, 30 SLAKE.
M5: 64/100. S10: 59/100. S10 corrections: 3. New errors: 8.
Each arm starts with empty memory and updates memory after each saved first answer.

Qwen37_M5_S10_full_trajectories_100pairs.json contains all saved records for both arms, paired by task ID.
The full report directory contains source code, search and replay records, per-question analysis, protocol, resource records and image indices.
SLAKE original and tool-derived images are included. OpenI images are referenced through their source pages.

Report: https://github.com/cw462/MedRAX-reproduction/blob/781d439f61c784a2726a9cb8ba9d7899d3bab331/reports/m5_rsi/rrsi_dev50_s10_val100_20261120/README.md
